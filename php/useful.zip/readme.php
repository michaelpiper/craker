<?php
// foreach ($a as $key => $r) {
// 		# code...
// 		echo "<span style='color:blue'>using keyword</span><br/>\n";
// 		echo "<span style='color:orange'>{$r}</span><br/>\n";
// 		if (in_array(strtolower($r), $password)){
// 			$r=strtolower($r);
// 			echo "<span style='color:green;font-size:42px;'>match found {$r}</span><br/>\n";
// 			sleep(4);
// 		}
// 		elseif(in_array(strtoupper($r), $password)){
// 			$r=strtoupper($r);
// 			echo "<span style='color:green;font-size:42px;'>match found {$r}</span><br/>\n";
// 			sleep(4);
// 		}
// 		elseif(in_array($r, $password)){
// 			echo "<span style='color:green;font-size:42px;'>match found {$r}</span><br/>\n";
// 			sleep(4);
// 		}
// 		else{
// 			echo "<span style='color:gold'>searching...</span><br/>\n";
// 		}
// 	}

?>